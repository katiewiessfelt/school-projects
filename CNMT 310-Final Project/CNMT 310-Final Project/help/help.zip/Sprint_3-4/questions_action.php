<?php

require_once("includes.php");
require_once("classes/SiteTemplate.php");
require_once("layout.php");

$page = new SiteTemplate("Questions");
$page->addHeadElement('<link rel="stylesheet" href=styles/layout.css>');
$page->addHeadElement('<style>#questions {text-decoration: underline;}</style>');
$page->finalizeTopSection();
$page->finalizeBottomSection();

print $page->getTopSection();

require_once("classes/WebServiceClient.php");

//answer input is required
$required = array("answer");
$_SESSION['errors'] = array();
foreach ($required as $index => $value) {
  if (!isset($_POST[$value]) || empty($_POST[$value])) {
    $_SESSION['errors'][] = "Please enter your answer";
    die(header("Location: " . QUESTIONS_PAGE));
  }
}

$message = "";
//check that the user is logged in
if (!isset($_SESSION['name'])) {
    $message = "<h3 id='message'>You are not currently logged in.</h3><br><p>Click <a href='login.php'>here</a> to login.</p>";
    print $message;
} 
else { //send the data
    $client = new WebServiceClient("https://cnmt310.braingia.org/qws/testq.php");
    $data = array("apikey" => APIKEY,
                  "apiuser" => APIUSER
    );
    $client->setPostFields($data);
    $authenticationRequest = $client->send();
    $authObject = json_decode($authenticationRequest);

    if (!is_object($authObject)) {
        $_SESSION['errors'][] = "Error: Authentication Issues";
        die(header("Location: " . QUESTIONS_PAGE));
    }

    if ($authObject->result == "Success") {

    } else {
        $_SESSION['errors'][] = $authObject->message;
    }
}

print $page->getBottomSection();
