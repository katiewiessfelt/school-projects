<?php

require_once("includes.php");
require_once("classes/SiteTemplate.php");

$page = new SiteTemplate("Questions");
$page->addHeadElement('<link rel="stylesheet" href=styles/layout.css>');
$page->addHeadElement('<style>#questions {text-decoration: underline;}</style>');
$page->finalizeTopSection();
$page->finalizeBottomSection();

print $page->getTopSection();

require_once("layout.php");

$message = "";
if (!isset($_SESSION['name'])) {
    $message = "<h3 id='message'>You are not currently logged in.</h3><br><p>Click <a href='login.php'>here</a> to login.</p>";
    print $message;
} else {
    print "<form class='question-form' action='questions_action.php' method='POST'>";
    if (isset($_SESSION['errors']) && count($_SESSION['errors']) > 0) {
        foreach ($_SESSION['errors'] as $errorIndex => $errorMessage) {
            print $errorMessage . "<br><br>\n";
        }
        unset($_SESSION['errors']);
    }
    print "<h4 id='question' name='question'>Question goes here</h4>";
    print "<label for='answer'><b>Answer:</b></label>";
    print "<input type='text' name='answer'><br>";
    print "<input type='submit' value='Check Answer'>";
    print "</form>\n";
}

print $page->getBottomSection();
