<?php

session_start();

print "Session ID is " . session_id();
