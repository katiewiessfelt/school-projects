<?php
print password_hash("pass1", PASSWORD_DEFAULT) . PHP_EOL;
print password_hash("pass2", PASSWORD_DEFAULT) . PHP_EOL;