# phpclasses_ws
Web Service Client Class (using cURL)
